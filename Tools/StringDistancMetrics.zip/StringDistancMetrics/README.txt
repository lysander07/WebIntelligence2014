Compile with:

javac LevenshteinDistance.java
javac JaroWinkler.java

Run with:

java LevenshteinDistance <string1> <string2>

java JaroWinkler <string1> <string2>
