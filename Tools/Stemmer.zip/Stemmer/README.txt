Compile with:

javac Stemmer.java

Run with:

java Stemmer <text-file>
 