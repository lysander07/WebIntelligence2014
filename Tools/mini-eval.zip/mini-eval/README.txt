Compile with:

javac EvalUtil.java


Run with:

java EvalUtil <gold-file> <result-file>

<gold-file> : Contains the 'a href' annotated text used as ground truth.	
<result-file> 	: Contains the 'a href' annotated text to compare with ground truth.
 