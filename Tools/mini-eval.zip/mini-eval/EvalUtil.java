import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.util.HashSet;
import java.util.Set;
import java.util.TreeSet;

public class EvalUtil {

	public static Set<String> extractURIsFromTextFile(String fileName) throws IOException {
		// read file line by line
		Set<String> list = new TreeSet<String>();
		BufferedReader br = new BufferedReader(new FileReader(fileName));
		String line;
		while ((line = br.readLine()) != null) {
			list.addAll(getURIsFromText(line));
		}
		br.close();
		return list;
	}

	private static Set<String> getURIsFromText(String text) throws UnsupportedEncodingException {
		Set<String> result = new TreeSet<String>();
		String[] tokens = text.replaceAll("'", "\"").split("href=\"");
		for (String t : tokens) {
			if (t.startsWith("http")) {
				String url = URLDecoder.decode(t.substring(0, t.indexOf("\"")), "UTF-8");
				result.add(url);
			}
		}
		return result;
	}

	public static void main(String[] args) throws IOException {

		if (args.length != 2) {
			System.err.println("Usage: java EvalUtil <gold-file> <result-file>");
			System.err.println("	<gold-file> 	: Contains the 'a href' annotated text used as ground truth.");
			System.err.println("	<result-file> 	: Contains the 'a href' annotated text to compare with ground truth.");
			System.exit(1);
		}

		Set<String> goldset = extractURIsFromTextFile(args[0]);
		Set<String> resultset = extractURIsFromTextFile(args[1]);
		
		Set<String> found = new HashSet<String>();
		found.addAll(goldset);
		found.retainAll(resultset);
		System.out.println("Found (TP): " + found.size() + " (" + (100.0 * found.size() / goldset.size()) + "%)");

		Set<String> notFound = new HashSet<String>();
		notFound.addAll(goldset);
		notFound.removeAll(resultset);
		System.out.println("Not found (FN): " + notFound.size() + " (" + (100.0 * notFound.size() / goldset.size()) + "%)");
		for (String uri: notFound){
			System.out.println("  " + uri);
		}

		Set<String> wrong = new HashSet<String>();
		wrong.addAll(resultset);
		wrong.removeAll(goldset);		
		System.out.println("Wrong (FP): " + wrong.size());
		for (String uri: wrong){
			System.out.println("  " + uri);
		}
		System.out.println("--------");
		
		double p = 1.0 * found.size() / (found.size() + wrong.size());
		double r = 1.0 * found.size() / (found.size() + notFound.size());
		double f = (2 * p * r / (p + r));
		System.out.println("Prec: " + p);
		System.out.println("Rec : " + r);
		System.out.println("F1  : " + f);
	}
	
}
